/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabfinaltecnicas;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;

/**
 *
 * @author Daniel
 */
public class ModuloOperacional {
    /*
     Toda parte de calculo deve ser feita aqui
     */
    private int numID;

    public  ModuloOperacional() {
       // ids = new HashMap<>();

    }  
}
