/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabfinaltecnicas;

/**
 *
 * @author Daniel
 */


//Este Aqui é o mais obscuro dos Cartões, pois a unica informação é que ele não paga 
//Pois ele nao pode ter Saldo e nem id, pois ele nãoé recarregavel lol
public class CartaoResidente implements Cartao {
    
    
    
}
